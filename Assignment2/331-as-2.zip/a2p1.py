#!/usr/bin/python3

#---------------------------------------------------------------
#
# CMPUT 331 Student Submission License
# Version 1.0
# Copyright 2026 Chitkarsh Rathi
#
# Redistribution is forbidden in all circumstances. Use of this software
# without explicit authorization from the author is prohibited.
#
# This software was produced as a solution for an assignment in the course
# CMPUT 331 - Computational Cryptography at the University of
# Alberta, Canada. This solution is confidential and remains confidential 
# after it is submitted for grading.
#
# Copying any part of this solution without including this copyright notice
# is illegal.
#
# If any portion of this software is included in a solution submitted for
# grading at an educational institution, the submitter will be subject to
# the sanctions for plagiarism at that institution.
#
# If this software is found in any public website or public repository, the
# person finding it is kindly requested to immediately report, including 
# the URL or other repository locating information, to the following email
# address:
#
#          gkondrak <at> ualberta.ca
#
#---------------------------------------------------------------

"""
CMPUT 331 Assignment 2 Student Solution
September 2026
Author: Chitkarsh Rathi
"""

def encipherMessage(key: int, message: str) -> str:
    ciphertext = ''

    for i in range(key):
        ciphertext += message[i::key]
    return ciphertext

def decipherMessage(key: int, message: str) -> str:
    length  = len(message)

    rows = length // key
    if length % key != 0:
        rows += 1

    cols = []
    idx = 0
    space = (rows * key) - length

    for i in range(key):
        if i < key - space:
            col_len = rows
        else:
            col_len = rows - 1

        cols.append(message[idx:idx + col_len])
        idx += col_len

    plaintext = ''

    for r in range(rows):
        for c in cols:
            if r < len(c):
                plaintext += c[r]

    return plaintext

def test():
    assert encipherMessage(5, "CIPHERS ARE FUN") == "CREIS P FHAUERN"
    assert decipherMessage(2, encipherMessage(2, "SECRET")) == "SECRET"
    assert decipherMessage(3, encipherMessage(3, "CIPHERS ARE FUN")) == "CIPHERS ARE FUN"
    assert decipherMessage(4, encipherMessage(4, "HELLO WORLD")) == "HELLO WORLD"

from sys import flags

if __name__ == "__main__" and not flags.interactive:
    test()
