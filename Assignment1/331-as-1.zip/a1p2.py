#!/usr/bin/python3

#---------------------------------------------------------------
#
# CMPUT 331 Student Submission License
# Version 1.0
# Copyright 2026 Chitkarsh Rathi
#
# Redistribution is forbidden in all circumstances. Use of this software
# without explicit authorization from the author is prohibited.
#
# This software was produced as a solution for an assignment in the course
# CMPUT 331 - Computational Cryptography at the University of
# Alberta, Canada. This solution is confidential and remains confidential 
# after it is submitted for grading.
#
# Copying any part of this solution without including this copyright notice
# is illegal.
#
# If any portion of this software is included in a solution submitted for
# grading at an educational institution, the submitter will be subject to
# the sanctions for plagiarism at that institution.
#
# If this software is found in any public website or public repository, the
# person finding it is kindly requested to immediately report, including 
# the URL or other repository locating information, to the following email
# address:
#
#          gkondrak <at> ualberta.ca
#
#---------------------------------------------------------------

"""
CMPUT 331 Assignment 1 Student Solution
September 2026
Author: Chitkarsh Rathi
"""


from sys import flags

LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

def get_map(letters=LETTERS):

    char_to_index = {char: index for index, char in enumerate(letters)}
    index_to_char = {index: char for index, char in enumerate(letters)}

    return char_to_index, index_to_char


def encrypt(message: str, key: str):
    message = message.upper()

    key = key.upper()
    translated = ''
    char_to_index, index_to_char = get_map()

    current_key = key

    for i in message:
        if i in char_to_index:
            shift = char_to_index[current_key]
            index = (char_to_index[i] + shift) % len(LETTERS)
            translated += index_to_char[index]

            current_key = i
        else:
            translated += i

    return translated

def decrypt(message: str, key: str):
    message = message.upper()
    key = key.upper()
    translated = ''
    char_to_index, index_to_char = get_map()

    current_key = key
    
    for i in message:
        if i in char_to_index:
            shift = char_to_index[current_key]
            index = (char_to_index[i] - shift) % len(LETTERS)

            decrypted_char = index_to_char[index]
            translated += decrypted_char
            current_key = decrypted_char
        else:
            translated += i

    return translated


def test():
    global SHIFTDICT, LETTERDICT 
    SHIFTDICT, LETTERDICT = get_map()
    assert decrypt(encrypt("FOO", "G"), "G") == "FOO"

if __name__ == "__main__" and not flags.interactive:
    test()