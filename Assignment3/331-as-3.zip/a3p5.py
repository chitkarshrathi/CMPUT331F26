#!/usr/bin/python3

# ---------------------------------------------------------------
#
# CMPUT 331 Student Submission License
# Version 1.0
# Copyright 2026 Chitkarsh Rathi
#
# Redistribution is forbidden in all circumstances. Use of this software
# without explicit authorization from the author is prohibited.
#
# This software was produced as a solution for an assignment in the course
# CMPUT 331 - Computational Cryptography at the University of
# Alberta, Canada. This solution is confidential and remains confidential
# after it is submitted for grading.
#
# Copying any part of this solution without including this copyright notice
# is illegal.
#
# If any portion of this software is included in a solution submitted for
# grading at an educational institution, the submitter will be subject to
# the sanctions for plagiarism at that institution.
#
# If this software is found in any public website or public repository, the
# person finding it is kindly requested to immediately report, including
# the URL or other repository locating information, to the following email
# address:
#
#          gkondrak <at> ualberta.ca
#
# ---------------------------------------------------------------

"""
CMPUT 331 Assignment 3 Student Solution
Author: Chitkarsh Rathi
"""

from sys import flags


def crack_rng(m, sequence):
    r2, r3, r4, r5, r6 = tuple(sequence)

    x1 = (r4 - r3) % m
    x2 = (r5 - r4) % m

    y1 = (r3 - r2) % m
    y2 = (r4 - r3) % m

    d1 = (r5 - r4) % m
    d2 = (r6 - r5) % m

    det = (x1 * y2 - y1 * x2) % m
    inv_det = pow(det, m - 2, m)

    a = (d1 * y2 - d2 * y1) * inv_det % m
    b = (x1 * d2 - x2 * d1) * inv_det % m
    c = (r4 - a * r3 - b * r2) % m

    return [a, b, c]

def test():
    assert crack_rng(17, [14, 13, 16, 3, 13]) == [3, 5, 9]


if __name__ == "__main__" and not flags.interactive:
    test()
